﻿using System;
using System.Collections.Generic;
using BlackjackWPF.Model;

namespace BlackjackWPF.ViewModel
{
    public class VMCard
    {
        private static readonly Dictionary<SUITS, string> SUITS_DICTIONARY = new Dictionary<SUITS, string>()
        {
            { SUITS.Clubs, "clubs" },
            { SUITS.Diamonds, "diamonds" },
            { SUITS.Hearts, "hearts" },
            { SUITS.Spades, "spades" },
        };

        private const string BLANK_CARD_PATH = "blank.png";
        private const string BACKSIDE_CARD_PATH = "taliban2.jpg";
        private const string EXTENSION = ".png";
        private const string POS_SUIT_SPLIT = "_of_";
        public Uri ImageSource { get; set; }
        public VALUES Val { get; }
        public SUITS Suit { get; }

        public static Dictionary<VALUES, string> VALUES_DICTIONARY1 { get; } = new Dictionary<VALUES, string>()
        {
            { VALUES.Ace, "ace" },
            { VALUES.Two, "2" },
            { VALUES.Three, "3" },
            { VALUES.Four, "4" },
            { VALUES.Five, "5" },
            { VALUES.Six, "6" },
            { VALUES.Seven, "7" },
            { VALUES.Eight, "8" },
            { VALUES.Nine, "9" },
            { VALUES.Ten, "10" },
            { VALUES.Jack, "jack" },
            { VALUES.Queen, "queen" },
            { VALUES.King, "king" },
        };


        //Opretter VMCard instans med deafult billede som er blank
        public VMCard()
        {
            ImageSource = new Uri(Environment.CurrentDirectory + Properties.Settings.Default.cardImagesDirectory + BLANK_CARD_PATH);
            Val = VALUES.Blank;
            Suit = SUITS.Blank;
        }

        public VMCard(VALUES val, SUITS suit)
        {
            if (val == VALUES.Blank || suit == SUITS.Blank)
            {
                ImageSource = new Uri(Environment.CurrentDirectory + Properties.Settings.Default.cardImagesDirectory + BLANK_CARD_PATH);
            }
            else if (val == VALUES.Unknown || suit == SUITS.Unknown)
            {
                ImageSource = new Uri(Environment.CurrentDirectory + Properties.Settings.Default.cardImagesDirectory + BACKSIDE_CARD_PATH);
            }
            else
            {
                ImageSource = new Uri(Environment.CurrentDirectory + Properties.Settings.Default.cardImagesDirectory + VALUES_DICTIONARY1[val] + POS_SUIT_SPLIT + SUITS_DICTIONARY[suit] + EXTENSION);
            }
            Val = val;
            Suit = suit;
        }
    }
}
