﻿using System;
using System.ComponentModel;
using System.Windows.Input;
using System.Windows;
using BlackjackWPF.Model;
using System.Windows.Media;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Runtime.CompilerServices;


namespace BlackjackWPF.ViewModel
{
    public class MainWindowViewModel : VMCard, INotifyPropertyChanged
    {

        #region Static members definition
        public enum LABELS { Wins, Ties, Losses };
        public enum PLAYERS { Dealer, Player };

        public const string WINS_DISPLAY_LABEL = "Wins: ";
        public const string TIES_DISPLAY_LABEL = "Ties: ";
        public const string LOSSES_DISPLAY_LABEL = "Losses: ";
        public const string PLAYER_WIN_STATUS_TEXT = "YOU WIN!";
        public const string DEALER_WIN_STATUS_TEXT = "DEALER WINS!";
        public const string TIE_STATUS_TEXT = "TIE!";
        public const string PLAYER_HEADER_TEXT = "Your Hand: {0}";
        public const string PLAYER_HIDDEN_HEADER_TEXT = "Your Hand";
        public const string DEALER_HEADER_TEXT = "Dealer's Hand: {0}";
        public const string DEALER_HIDDEN_HEADER_TEXT = "Dealer's Hand";
        #endregion

        #region properties


        public string WinsDisplay { get; set; }
        public string TiesDisplay { get; set; }
        public string LossesDisplay { get; set; }
        public Visibility IsStartVisible { get; set; }
        public bool IsStartEnabled { get; set; }
        public bool IsStandReady { get; set; }
        public bool IsHitReady { get; set; }

        public bool IsInputReady
        {
            get { return (IsStandReady && IsHitReady); }
            set
            {
                IsStandReady = value;
                NotifyPropertyChanged(nameof(IsStandReady));
                IsHitReady = value;
                NotifyPropertyChanged(nameof(IsHitReady));
            }
        }
        public Visibility IsRestartVisible { get; set; }
        public bool IsRestartEnabled { get; set; }
        public Visibility IsResetVisible { get; set; }
        public bool IsResetEnabled { get; set; }
        public Visibility IsDisplayLabelVisible { get; set; }
        public Brush DealerBorderColor { get; set; }
        public Brush PlayerBorderColor { get; set; }
        public BlackjackGame BlackjackGame { get; set; }
        public string StatusLabelText { get; set; }
        public string DealerBoxHeader { get; set; }
        public string PlayerBoxHeader { get; set; }

        #endregion


        #region Commands
        private ICommand startupCommand;
        public ICommand StartupCommand => startupCommand ?? (startupCommand = new NoParamRelayCommand<object>(() => { RunStartupActions(); }));


        private ICommand startGameCommand;
        public ICommand StartGameCommand => startGameCommand ?? (startGameCommand = new NoParamRelayCommand<string>(StartGame));


        private ICommand hitCommand;
        public ICommand HitCommand => hitCommand ?? (hitCommand = new NoParamRelayCommand<string>(DoPlayerHit));


        private ICommand standCommand;
        public ICommand StandCommand => standCommand ?? (standCommand = new NoParamRelayCommand<string>(DoPlayerStand));

        private ICommand restartGameCommand;
        public ICommand RestartGameCommand => restartGameCommand ?? (restartGameCommand = new NoParamRelayCommand<string>(RestartGame));

        private ICommand resetGameCommand;
        public ICommand ResetGameCommand => resetGameCommand ?? (resetGameCommand = new NoParamRelayCommand<string>(ResetGame));
        #endregion


        #region Methods definition
        public ObservableCollection<VMCard> DealerCardsList { get; set; }
        public ObservableCollection<VMCard> PlayerCardsList { get; set; }
        private void RunStartupActions()
        {
            DealerCardsList = new ObservableCollection<VMCard>();
            for (int i = 1; i <= 7; i++)
            {
                DealerCardsList.Add(new VMCard());
            }

            NotifyPropertyChanged("DealerCardsList");

            PlayerCardsList = new ObservableCollection<VMCard>();


            PlayerCardsList = new ObservableCollection<VMCard>();
            for (int i = 1; i <= 7; i++)
            {
                PlayerCardsList.Add(new VMCard());
            }
            NotifyPropertyChanged("PlayerCardsList");

            ChangeDisplayLabel(0, LABELS.Wins);
            ChangeDisplayLabel(0, LABELS.Ties);
            ChangeDisplayLabel(0, LABELS.Losses);

            IsResetEnabled = false;
            NotifyPropertyChanged(nameof(IsResetEnabled));
            IsResetVisible = Visibility.Hidden;
            NotifyPropertyChanged(nameof(IsResetVisible));
            IsRestartEnabled = false;
            NotifyPropertyChanged("IsRestartEnabled");
            IsRestartVisible = Visibility.Hidden;
            NotifyPropertyChanged("IsRestartVisible");
            IsStartEnabled = true;
            NotifyPropertyChanged("IsStartEnabled");
            IsStartVisible = Visibility.Visible;
            NotifyPropertyChanged("IsStartVisible");
            IsDisplayLabelVisible = Visibility.Hidden;
            NotifyPropertyChanged(nameof(IsDisplayLabelVisible));
            IsInputReady = false;
            NotifyPropertyChanged("IsInputReady");

            ChangeTotalLabel(0, PLAYERS.Dealer);
            ChangeTotalLabel(0, PLAYERS.Player);
        }

        private void StartGame()
        {
            IsStartEnabled = false;
            NotifyPropertyChanged("IsStartEnabled");
            IsStartVisible = Visibility.Hidden;
            NotifyPropertyChanged("IsStartVisible");
            IsDisplayLabelVisible = Visibility.Visible;
            NotifyPropertyChanged(nameof(IsDisplayLabelVisible));
            IsResetEnabled = true;
            NotifyPropertyChanged(nameof(IsResetEnabled));
            IsResetVisible = Visibility.Visible;
            NotifyPropertyChanged(nameof(IsResetVisible));

            ChangeTotalLabel(0, PLAYERS.Dealer);
            ChangeTotalLabel(0, PLAYERS.Player);
            StatusLabelText = "";
            NotifyPropertyChanged(nameof(StatusLabelText));

            if (BlackjackGame == null)
            {
                BlackjackGame = new BlackjackGame();
                BlackjackGame.SetDealer(new Dealer());
                BlackjackGame.Dealer.HandChanged += UpdateHands;
                BlackjackGame.SetPlayer(new Player());
                BlackjackGame.Player.HandChanged += UpdateHands;
            }

            BlackjackGame.DistributeHands();

            if (BlackjackGame.Player.GetHandTotal() == 21)
            {
                // Player got natural 21.
                IsResetEnabled = false;
                NotifyPropertyChanged(nameof(IsResetEnabled));
                IsResetVisible = Visibility.Hidden;
                NotifyPropertyChanged(nameof(IsResetVisible));
                IsRestartEnabled = true;
                NotifyPropertyChanged(nameof(IsRestartEnabled));
                IsRestartVisible = Visibility.Visible;
                NotifyPropertyChanged(nameof(IsRestartVisible));
                IsDisplayLabelVisible = Visibility.Hidden;
                NotifyPropertyChanged(nameof(IsDisplayLabelVisible));
                IsInputReady = false;
                NotifyPropertyChanged(nameof(IsInputReady));

                PlayerBorderColor = Brushes.DeepSkyBlue;
                NotifyPropertyChanged(nameof(PlayerBorderColor));
                BlackjackGame.Player.Wins++;
                ChangeDisplayLabel(BlackjackGame.Player.Wins, LABELS.Wins);
                StatusLabelText = PLAYER_WIN_STATUS_TEXT;
                NotifyPropertyChanged(nameof(StatusLabelText));

                DisplayDealerHand();
            }
            else
            {
                IsInputReady = true;
                NotifyPropertyChanged("IsInputReady");
            }
        }

        private void DoPlayerHit()
        {
            IsInputReady = false;
            NotifyPropertyChanged("IsInputReady");

            if (BlackjackGame.ActingPlayer == BlackjackGame.Player)
            {
                BlackjackGame.DoPlayerAction(BlackjackGame.ACTIONS.Hit);
            }

            if (BlackjackGame.Player.IsBusted)
            {
                DealerBorderColor = Brushes.DeepSkyBlue;
                NotifyPropertyChanged(nameof(DealerBorderColor));
                BlackjackGame.Player.Losses++;
                ChangeDisplayLabel(BlackjackGame.Player.Losses, LABELS.Losses);
                StatusLabelText = DEALER_WIN_STATUS_TEXT;
                NotifyPropertyChanged(nameof(StatusLabelText));
                IsInputReady = false;
                NotifyPropertyChanged("IsInputReady");
                IsResetEnabled = false;
                NotifyPropertyChanged(nameof(IsResetEnabled));
                IsResetVisible = Visibility.Hidden;
                NotifyPropertyChanged(nameof(IsResetVisible));
                IsDisplayLabelVisible = Visibility.Hidden;
                NotifyPropertyChanged(nameof(IsDisplayLabelVisible));
                IsRestartEnabled = true;
                NotifyPropertyChanged(nameof(IsRestartEnabled));
                IsRestartVisible = Visibility.Visible;
                NotifyPropertyChanged(nameof(IsRestartVisible));

                DisplayDealerHand();
            }
            else
            {
                IsInputReady = true;
                NotifyPropertyChanged("IsInputReady");
            }
        }

        private void DoPlayerStand()
        {
            IsInputReady = false;
            NotifyPropertyChanged(nameof(IsInputReady));

            BlackjackGame.ActingPlayer = BlackjackGame.Dealer;

            if (BlackjackGame.Dealer.GetHandTotal() <= BlackjackGame.Player.GetHandTotal())
            {
                do
                {
                    BlackjackGame.DoDealerAction();
                } while (BlackjackGame.ActingPlayer == BlackjackGame.Dealer);
            }

            if (BlackjackGame.Dealer.IsBusted && !BlackjackGame.Player.IsBusted)
            {
                PlayerBorderColor = Brushes.DeepSkyBlue;
                NotifyPropertyChanged(nameof(PlayerBorderColor));
                BlackjackGame.Player.Wins++;
                ChangeDisplayLabel(BlackjackGame.Player.Wins, LABELS.Wins);
                StatusLabelText = PLAYER_WIN_STATUS_TEXT;
                NotifyPropertyChanged(nameof(StatusLabelText));
            }
            else
            {
                BasePlayer winner = BlackjackGame.GetWinner();
                if (winner == null)
                {
                    // It was a tie.
                    DealerBorderColor = Brushes.DeepSkyBlue;
                    NotifyPropertyChanged(nameof(DealerBorderColor));
                    PlayerBorderColor = Brushes.DeepSkyBlue;
                    NotifyPropertyChanged(nameof(PlayerBorderColor));
                    StatusLabelText = TIE_STATUS_TEXT;
                    NotifyPropertyChanged(nameof(StatusLabelText));
                    BlackjackGame.Player.Ties++;
                    ChangeDisplayLabel(BlackjackGame.Player.Ties, LABELS.Ties);
                }
                else if (winner == BlackjackGame.Player)
                {
                    // player won.
                    PlayerBorderColor = Brushes.DeepSkyBlue;
                    NotifyPropertyChanged(nameof(PlayerBorderColor));
                    BlackjackGame.Player.Wins++;
                    ChangeDisplayLabel(BlackjackGame.Player.Wins, LABELS.Wins);
                    StatusLabelText = PLAYER_WIN_STATUS_TEXT;
                    NotifyPropertyChanged(nameof(StatusLabelText));

                }
                else if (winner == BlackjackGame.Dealer)
                {
                    // Dealer won.
                    DealerBorderColor = Brushes.DeepSkyBlue;
                    NotifyPropertyChanged(nameof(DealerBorderColor));
                    BlackjackGame.Player.Losses++;
                    ChangeDisplayLabel(BlackjackGame.Player.Losses, LABELS.Losses);
                    StatusLabelText = DEALER_WIN_STATUS_TEXT;
                    NotifyPropertyChanged(nameof(StatusLabelText));
                }
            }

            IsResetEnabled = false;
            NotifyPropertyChanged(nameof(IsResetEnabled));
            IsResetVisible = Visibility.Hidden;
            NotifyPropertyChanged(nameof(IsResetVisible));
            IsDisplayLabelVisible = Visibility.Hidden;
            NotifyPropertyChanged(nameof(IsDisplayLabelVisible));
            IsRestartEnabled = true;
            NotifyPropertyChanged(nameof(IsRestartEnabled));
            IsRestartVisible = Visibility.Visible;
            NotifyPropertyChanged(nameof(IsRestartVisible));

            DisplayDealerHand();
        }

        private void RestartGame()
        {
            BlackjackGame.ResetGame();

            DealerBorderColor = Brushes.Green;
            NotifyPropertyChanged(nameof(DealerBorderColor));
            PlayerBorderColor = Brushes.Green;
            NotifyPropertyChanged(nameof(PlayerBorderColor));

            IsRestartEnabled = false;
            NotifyPropertyChanged(nameof(IsRestartEnabled));
            IsRestartVisible = Visibility.Hidden;
            NotifyPropertyChanged(nameof(IsRestartVisible));

            IsStartEnabled = true;
            NotifyPropertyChanged(nameof(IsStartEnabled));
            IsStartVisible = Visibility.Visible;
            NotifyPropertyChanged(nameof(IsStartVisible));

            ChangeTotalLabel(0, PLAYERS.Dealer);
            ChangeTotalLabel(0, PLAYERS.Player);
        }

        private void DisplayDealerHand()
        {
            ChangeTotalLabel(BlackjackGame.Dealer.GetHandTotal(), PLAYERS.Dealer);

            for (int i = 0; i < BlackjackGame.Dealer.CurrentHand.Length; i++)
            {
                UpdateHands(BlackjackGame.Dealer, new HandEventArgs(i, BlackjackGame.Dealer.CurrentHand[i]));
            }
        }

        private void UpdateHands(object sender, HandEventArgs args)
        {
            if (sender is Dealer)
            {
                Card cCard = BlackjackGame.Dealer.GetCard(args.Index, !IsRestartEnabled);
                DealerCardsList[args.Index] = new VMCard(cCard.Values, cCard.Suit);
            }
            else if (sender is Player)
            {
                PlayerCardsList[args.Index] = new VMCard(args.Card.Values, args.Card.Suit);
                ChangeTotalLabel(BlackjackGame.Player.GetHandTotal(), PLAYERS.Player);
            }
        }

        private void ResetGame()
        {
            RestartGame();
            ChangeDisplayLabel(0, LABELS.Wins);
            ChangeDisplayLabel(0, LABELS.Ties);
            ChangeDisplayLabel(0, LABELS.Losses);
            BlackjackGame.Player.Wins = 0;
            BlackjackGame.Player.Ties = 0;
            BlackjackGame.Player.Losses = 0;
            StartGame();
        }


        //Sætter den specifikke label til at være det specifikke nummer 
        private void ChangeDisplayLabel(int num, LABELS label)
        {
            switch (label)
            {
                case LABELS.Wins:
                    WinsDisplay = WINS_DISPLAY_LABEL + num;
                    NotifyPropertyChanged(nameof(WinsDisplay));
                    break;
                case LABELS.Ties:
                    TiesDisplay = TIES_DISPLAY_LABEL + num;
                    NotifyPropertyChanged(nameof(TiesDisplay));
                    break;
                case LABELS.Losses:
                    LossesDisplay = LOSSES_DISPLAY_LABEL + num;
                    NotifyPropertyChanged(nameof(LossesDisplay));
                    break;
            }
            return;
        }

        private void ChangeTotalLabel(int num, PLAYERS player)
        {
            switch (player)
            {
                case PLAYERS.Dealer:
                    if (num == 0)
                    { DealerBoxHeader = DEALER_HIDDEN_HEADER_TEXT; }
                    else
                    { DealerBoxHeader = String.Format(DEALER_HEADER_TEXT, num); }
                    NotifyPropertyChanged(nameof(DealerBoxHeader));
                    break;
                case PLAYERS.Player:
                    if (num == 0)
                    { PlayerBoxHeader = PLAYER_HIDDEN_HEADER_TEXT; }
                    else
                    { PlayerBoxHeader = String.Format(PLAYER_HEADER_TEXT, num); }
                    NotifyPropertyChanged(nameof(PlayerBoxHeader));
                    break;
            }
        }

        #endregion

        //Med inspiration fra GUI lektion "agent" assignment
        #region INotifyPropertyChanged implementation
        public event PropertyChangedEventHandler PropertyChanged;

        private void NotifyPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
        #endregion
    }


}
