﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace BlackjackWPF.Model
{
 
    public class Deck
    {
        // Members 
        //public Stack<Card> stack { get; private set; }

        private Stack<Card> _cards = new Stack<Card>();


        // Constructor

        #region Setting up a deck of cards 
        public Deck()
        {

            //Vi prøver at få denne metode til at virke
            //var suits = (SUITS[])Enum.GetValues(typeof(SUITS));
            //var values = (VALUES[])Enum.GetValues(typeof(VALUES));
            //Stack<Card> _cards = new Stack<Card>(suits.Length * values.Length);
            //foreach (var suit in suits)
            //{
            //    foreach (var value in values)
            //    {
            //        _cards.Push(new Card(value, suit));
            //    }
            //}


            _cards = new Stack<Card>();

            _cards.Push(new Card(VALUES.Ace, SUITS.Clubs));
            _cards.Push(new Card(VALUES.Ace, SUITS.Diamonds));
            _cards.Push(new Card(VALUES.Ace, SUITS.Hearts));
            _cards.Push(new Card(VALUES.Ace, SUITS.Spades));

            _cards.Push(new Card(VALUES.Two, SUITS.Clubs));
            _cards.Push(new Card(VALUES.Two, SUITS.Diamonds));
            _cards.Push(new Card(VALUES.Two, SUITS.Hearts));
            _cards.Push(new Card(VALUES.Two, SUITS.Spades));

            _cards.Push(new Card(VALUES.Three, SUITS.Clubs));
            _cards.Push(new Card(VALUES.Three, SUITS.Diamonds));
            _cards.Push(new Card(VALUES.Three, SUITS.Hearts));
            _cards.Push(new Card(VALUES.Three, SUITS.Spades));

            _cards.Push(new Card(VALUES.Four, SUITS.Clubs));
            _cards.Push(new Card(VALUES.Four, SUITS.Diamonds));
            _cards.Push(new Card(VALUES.Four, SUITS.Hearts));
            _cards.Push(new Card(VALUES.Four, SUITS.Spades));

            _cards.Push(new Card(VALUES.Five, SUITS.Clubs));
            _cards.Push(new Card(VALUES.Five, SUITS.Diamonds));
            _cards.Push(new Card(VALUES.Five, SUITS.Hearts));
            _cards.Push(new Card(VALUES.Five, SUITS.Spades));

            _cards.Push(new Card(VALUES.Six, SUITS.Clubs));
            _cards.Push(new Card(VALUES.Six, SUITS.Diamonds));
            _cards.Push(new Card(VALUES.Six, SUITS.Hearts));
            _cards.Push(new Card(VALUES.Six, SUITS.Spades));

            _cards.Push(new Card(VALUES.Seven, SUITS.Clubs));
            _cards.Push(new Card(VALUES.Seven, SUITS.Diamonds));
            _cards.Push(new Card(VALUES.Seven, SUITS.Hearts));
            _cards.Push(new Card(VALUES.Seven, SUITS.Spades));

            _cards.Push(new Card(VALUES.Eight, SUITS.Clubs));
            _cards.Push(new Card(VALUES.Eight, SUITS.Diamonds));
            _cards.Push(new Card(VALUES.Eight, SUITS.Hearts));
            _cards.Push(new Card(VALUES.Eight, SUITS.Spades));

            _cards.Push(new Card(VALUES.Nine, SUITS.Clubs));
            _cards.Push(new Card(VALUES.Nine, SUITS.Diamonds));
            _cards.Push(new Card(VALUES.Nine, SUITS.Hearts));
            _cards.Push(new Card(VALUES.Nine, SUITS.Spades));

            _cards.Push(new Card(VALUES.Ten, SUITS.Clubs));
            _cards.Push(new Card(VALUES.Ten, SUITS.Diamonds));
            _cards.Push(new Card(VALUES.Ten, SUITS.Hearts));
            _cards.Push(new Card(VALUES.Ten, SUITS.Spades));

            _cards.Push(new Card(VALUES.Jack, SUITS.Clubs));
            _cards.Push(new Card(VALUES.Jack, SUITS.Diamonds));
            _cards.Push(new Card(VALUES.Jack, SUITS.Hearts));
            _cards.Push(new Card(VALUES.Jack, SUITS.Spades));

            _cards.Push(new Card(VALUES.Queen, SUITS.Clubs));
            _cards.Push(new Card(VALUES.Queen, SUITS.Diamonds));
            _cards.Push(new Card(VALUES.Queen, SUITS.Hearts));
            _cards.Push(new Card(VALUES.Queen, SUITS.Spades));

            _cards.Push(new Card(VALUES.King, SUITS.Clubs));
            _cards.Push(new Card(VALUES.King, SUITS.Diamonds));
            _cards.Push(new Card(VALUES.King, SUITS.Hearts));
            _cards.Push(new Card(VALUES.King, SUITS.Spades));

        }
        #endregion

        #region Methods definition

        // Returner den shuffled version af et givet deck --> fandt algoritmen på google
        protected static Stack<Card> Shuffle(Stack<Card> deck)
        {
            Random rdm = new Random();
            Card[] cardArr = deck.ToArray<Card>();
            Card[] outputCardArr = new Card[cardArr.Length];

            for (int i = cardArr.Length - 1; i >= 0; i--)
            {
                do
                {
                    int j = rdm.Next(cardArr.Length);
                    if (!outputCardArr.Contains<Card>(cardArr[j]))
                    { outputCardArr[i] = cardArr[j]; }
                } while (outputCardArr[i] == null);
            }

            return BuildStack(outputCardArr);
        }

        public void ShuffleDeck()
        {
            _cards = Shuffle(_cards);
        }

        // Konventer et array af kort objekter til en stack.
        private static Stack<Card> BuildStack(Card[] inputArr)
        {
            Stack<Card> outputStack = new Stack<Card>();
            for (int i = inputArr.Length - 1; i >= 0; i--)
            {
                outputStack.Push(inputArr[i]);
            }
            return outputStack;
        }

        // Trækker et kort fra toppen af kort bunken da det er en stack og retruner det.
        public Card DrawCard()
        {
            return _cards.Pop();
        }
        #endregion
    }
}
