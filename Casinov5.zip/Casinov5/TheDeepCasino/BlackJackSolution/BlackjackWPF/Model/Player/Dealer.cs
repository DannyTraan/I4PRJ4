﻿namespace BlackjackWPF.Model
{
    public class Dealer : BasePlayer
    {
        public Dealer()
        {
            currentHand = new Card[BlackjackGame.Amount_of_cards];
            BlankingHand();
            Wins = 0;
            Ties = 0;
            Losses = 0;
        }

        public override BlackjackGame.ACTIONS GetAction()
        {
            return GetHandTotal() <= 16 ? BlackjackGame.ACTIONS.Hit : BlackjackGame.ACTIONS.Stand;
        }

        public Card GetCard(int index, bool isHidden = true)
        {
            if (isHidden && index == 0)
            {
                return new Card(VALUES.Unknown, SUITS.Unknown);
            }

            return CurrentHand[index];
        }

    }
}
