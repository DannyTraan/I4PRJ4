﻿namespace BlackjackWPF.Model
{
    public class Player : BasePlayer
    {
        public Player()
        {
            currentHand = new Card[BlackjackGame.Amount_of_cards];
            BlankingHand();
            Wins = 0;
            Ties = 0;
            Losses = 0;
        }

        //Vil altid returnere Hit fra ACTION
        public override BlackjackGame.ACTIONS GetAction()
        {
            return BlackjackGame.ACTIONS.Hit;
        }
    }
}
