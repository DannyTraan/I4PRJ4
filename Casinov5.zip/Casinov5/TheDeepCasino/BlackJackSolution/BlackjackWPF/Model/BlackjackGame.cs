﻿using System.Collections.Generic;

namespace BlackjackWPF.Model
{
    public class BlackjackGame /*: Game*/
    {
        public enum ACTIONS { Hit, Stand };

        protected Deck cardDeck;
        public Deck CardDeck => cardDeck;

        // Variables 
        public const int Max_Hand_Value = 21;
        public const int Amount_of_cards = 7;

        // Members 
        public Dealer Dealer { get; set; }
        public Player Player { get; set; }
        public BasePlayer ActingPlayer { get; set; }
        public Stack<Card> BurnDeck { get; set; } = new Stack<Card>();


        // Constructor 
        public BlackjackGame()
        {
            cardDeck = new Deck();
            CardDeck.ShuffleDeck();
        }


        #region Methods definition
        public void ResetGame()
        {
            List<Card> dealerCards = Dealer.ReturnCards();
            foreach (Card cCard in dealerCards)
            {
                BurnDeck.Push(cCard);
            }

            List<Card> playerCards = Player.ReturnCards();
            foreach (Card cCard in playerCards)
            {
                BurnDeck.Push(cCard);
            }

            Player.IsBusted = false;
            Dealer.IsBusted = false;
        }

        public BasePlayer GetWinner()
        {
            int dealerScore = Dealer.GetHandTotal();
            int playerScore = Player.GetHandTotal();

            if (dealerScore == playerScore)
            {
                return null;
            }
            if (dealerScore > playerScore)
            {
                return Dealer;
            }
            return Player;
        }

        public void DoPlayerAction(ACTIONS action)
        {
            if (action == ACTIONS.Hit)
            {
                Player.AddCardToHand(CardDeck.DrawCard());
            }
            else
            {
                ActingPlayer = Dealer;
            }

            if (IsBusted(Player))
            {
                Player.IsBusted = true;
            }
        }

        public void DoDealerAction()
        {
            ACTIONS dealerAction = Dealer.GetAction();
            if (dealerAction == ACTIONS.Hit)
            {
                Dealer.AddCardToHand(CardDeck.DrawCard());
            }
            else
            {
                ActingPlayer = Player;
            }

            if (IsBusted(Dealer))
            {
                Dealer.IsBusted = true;
                ActingPlayer = Player;
            }
        }

        public bool IsBusted(BasePlayer player)
        {
            return player.GetHandTotal() > Max_Hand_Value;
        }

        // Udeller 2 kort til hver af spillerne.
        public void DistributeHands()
        {

            for (int i = 1; i <= 2; i++)
            {
                Player.AddCardToHand(CardDeck.DrawCard());
                Dealer.AddCardToHand(CardDeck.DrawCard());
            }
            ActingPlayer = Player;
        }

        public void SetDealer(Dealer dealer)
        {
            Dealer = dealer;
        }

        public void SetPlayer(Player player)
        {
            Player = player;
        }
        #endregion
    }
}
