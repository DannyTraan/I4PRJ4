﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DeepCasinoProjekt.Roulette.Models;
using NSubstitute;
using NUnit.Framework;

namespace DeepCasinoProjekt.Unit.Test
{
    [TestFixture]
    [Author("Semesterprojekt Gr. 2")]
    public class WinOrLoseTest
    {
        //Demand
        private string _userName;
        private int _userWallet;

        //uut
        private RoulettePlayer _uut;

        //Required
        private int _wheel;
        private int _spin;
        private static readonly int[] Reds =
        {
            32, 19, 21, 25, 34, 27, 36, 30, 23, 5, 16, 1, 14, 9, 18, 7, 12, 3
        };

        [SetUp]
        public void Setup()
        {
            _uut = new RoulettePlayer(_userName, _userWallet);

            _wheel = 34;
            _spin = _wheel;

            _userName = "TestUser";
            _userWallet = 1000;
        }

        //Due to the randomizer always getting a random number,
        //the wheel have been modified to only have one number.
        [Test]
        public void WinOrLose_ChecksIfEvenNumberBetIsWonOrLost()
        {
            var win = "You've won!";
            var lost = "You've lost!";

            if (_spin % 2 == 0)
            {
                Console.WriteLine(win);
            }
            else
            {
                Console.WriteLine(lost);
            }

            Assert.That(_spin % 2 == 0, Is.True);
        }

        //Same case.
        [Test]
        public void WinOrLose_ChecksIfRedBetIsWonOrLost()
        {
            var win = "You've won!";
            var lost = "You've lost!";

            if (Reds.Contains(_spin))
            {
                Console.WriteLine(win);
            }
            else
            {
                Console.WriteLine(lost);
            }

            Assert.That(Reds.Contains(_spin), Is.True);
        }
    }
}
