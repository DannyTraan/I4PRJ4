﻿using DeepCasinoProjekt.Models;

namespace DeepCasinoProjekt.Interfaces
{
    public interface IView
    {
        void AddCards(BlackJackPlayer one, BlackJackPlayer two);
        void DealButton(bool show);
        void DisplayName(string name);
        void ResetResult();
        void DisplayMoney(BlackJackPlayer one, BlackJackPlayer two);
        void DisplayPoints(BlackJackPlayer player);
        void EndGame(BlackJackPlayer one, BlackJackPlayer two, int bet);
    }
}
