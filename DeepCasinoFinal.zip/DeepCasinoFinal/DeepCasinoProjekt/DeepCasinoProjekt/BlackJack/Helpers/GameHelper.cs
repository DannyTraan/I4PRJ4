﻿using DeepCasinoProjekt.Models;

namespace DeepCasinoProjekt.BlackJack.Helpers
{
    public class GameHelper
    {
        public static void AddAces(BlackJackPlayer player, int card)
        {
            if (card == 11)
            {
                player.Aces++;
            }
        }

        public static BlackJackPlayer CalculateWinner(BlackJackPlayer one, BlackJackPlayer two)
        {
            if ((one.Score > two.Score || two.Score > 21) && one.Score <= 21)
            {
                return one;
            }
            if ((two.Score > one.Score || one.Score > 21) && two.Score <= 21)
            {
                return two;
            }

            return null;
        }

        public static bool HasAces(BlackJackPlayer player)
        {
            if (player.Aces > 0)
            {
                player.Aces--;
                player.Score -= 10;
                return true;
            }

            return false;
        }

        public static void ResetGame(BlackJackPlayer one, BlackJackPlayer two)
        {
            one.Reset();
            two.Reset();
        }

        public static void ResetImages(BlackJackPlayer one, BlackJackPlayer two)
        {
            one.Images.ForEach(x => x.Source = null);
            two.Images.ForEach(x => x.Source = null);

            two.Images[0].Source = two.ImageBack;
            two.Images[1].Source = two.ImageBack;
        }
    }
}
