﻿using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using DeepCasinoProjekt.BlackJack.Helpers;
using DeepCasinoProjekt.BlackJack.ViewModels;
using DeepCasinoProjekt.Interfaces;
using DeepCasinoProjekt.Models;

namespace DeepCasinoProjekt
{
    /// <summary>
    /// Interaction logic for BlackjackScreen.xaml
    /// </summary>
    public partial class BlackjackScreen : IView
    {
        //private readonly Button[] _defaultButtons;
        //private readonly Button[] _splitButtons;

        readonly Player _player;

        public BlackjackScreen(Player p)
        {
            InitializeComponent();
            _player = p;
            //_defaultButtons = new[] { Hit, Stand, Split };
            //_splitButtons = new[] { HitLeft, HitRight, StandLeft, StandRight };
            DataContext = new GameViewModel(this, p);
        }

        public BlackjackScreen()
        {
            InitializeComponent();
            //_defaultButtons = new[] { Hit, Stand, Split };
            //_splitButtons = new[] { HitLeft, HitRight, StandLeft, StandRight };
            DataContext = new GameViewModel(this, _player);
        }

        public void AddCards(BlackJackPlayer one, BlackJackPlayer two)
        {
            AddImages(one, PlayerImages);
            AddImages(two, ComputerImages);
        }

        private void AddImages(BlackJackPlayer player, Grid grid)
        {
            for (var i = 0; i < VisualTreeHelper.GetChildrenCount(grid); i++)
            {
                var child = VisualTreeHelper.GetChild(grid, i);
                player.Images.Add((Image)child);
            }
        }

        public void DealButton(bool show)
        {
            Deal.Visibility = show ? Visibility.Visible : Visibility.Hidden;
        }

        public void DisplayName(string name)
        {
            Name1.Content = name + ":";
            Name2.Content = name + ":";
        }

        public void ShowResult(string result)
        {
            Result.Content = result;
        }

        public void ResetResult()
        {
            Result.Content = string.Empty;
            ComputerPoints.Content = 0;
            PlayerPoints.Content = 0;
        }

        public void DisplayMoney(BlackJackPlayer one, BlackJackPlayer two)
        {
            PlayerMoney.Content = one.DeepCoins;
            ComputerMoney.Content = two.DeepCoins;
        }

        public void DisplayPoints(BlackJackPlayer player)
        {
            if (player.Name == "Computer")
            {
                ComputerPoints.Content = player.Score;
            }
            else
            {
                PlayerPoints.Content = player.Score;
            }
        }

        public void EndGame(BlackJackPlayer one, BlackJackPlayer two, int bet)
        {
            BlackJackPlayer winner = GameHelper.CalculateWinner(one, two);
            if (winner == null)
            {
                ShowResult("Draw!");
            }
            else
            {
                ShowResult(winner.Name + " won the game!");
                if (winner == one)
                {
                    one.DeepCoins += bet;
                    two.DeepCoins -= bet;
                }
                else
                {
                    two.DeepCoins += bet;
                    one.DeepCoins -= bet;
                }
            }
        }

    }
}
