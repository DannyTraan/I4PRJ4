﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Media.Imaging;
using DeepCasinoProjekt.BlackJack.Helpers;
using DeepCasinoProjekt.BlackJack.Models;
using DeepCasinoProjekt.Interfaces;
using DeepCasinoProjekt.Models;

namespace DeepCasinoProjekt.BlackJack.ViewModels
{
    public class GameViewModel 
    {
        public Commands Commands { get; }
        public Dictionary<int, BitmapImage[]> CardImages { get;}
        public BlackJackPlayer BlackJackPlayer { get; set; }
        public BlackJackPlayer Computer { get; set; }
        public TaskFactory TaskFactory { get; private set; }
        public IView View { get; set; }
        public string BetAmount { get; set; }
        public bool BetPlaced { get; set; }
        public bool DoubleCards { get; set; }
        public Random Random { get; set; }

        public GameViewModel(IView view, Player pl)
        {
            View = view;
            Random = new Random();
            Commands = new Commands(this);

            BlackJackPlayer = new BlackJackPlayer(pl.GetName(), pl.GetChips(), ImageClass.CreateImage("player"), 2);
            Computer = new BlackJackPlayer("Computer", pl.GetChips(), ImageClass.CreateImage("computer"), 2);
            view.DisplayMoney(BlackJackPlayer, Computer);
            view.DisplayName(pl.GetName());

            CardImages = ImageClass.GetBlackJackCards();
            view.AddCards(BlackJackPlayer, Computer);
            BlackJackPlayer.ShowBackside();
            Computer.ShowBackside();
            BetAmount = "100";
        }

        public void DealCards()
        {
            // Reset the board
            GameHelper.ResetImages(BlackJackPlayer, Computer);
            GameHelper.ResetGame(BlackJackPlayer, Computer);
            View.ResetResult();
            BetPlaced = true;

            int cardOne = Random.Next(2, 12);
            int cardTwo = Random.Next(2, 12);
            GameHelper.AddAces(BlackJackPlayer, cardOne);
            GameHelper.AddAces(BlackJackPlayer, cardTwo);

            BlackJackPlayer.Images[0].Source = ImageClass.RandomColorCard(CardImages.First(x => x.Key == cardOne).Value);
            BlackJackPlayer.Images[1].Source = ImageClass.RandomColorCard(CardImages.First(x => x.Key == cardTwo).Value);
            BlackJackPlayer.Score = cardOne + cardTwo;
            View.DisplayPoints(BlackJackPlayer);

            if (cardOne == cardTwo)
            {
                DoubleCards = true;
            }
            if (BlackJackPlayer.Score > 21)
            {
                GameHelper.HasAces(BlackJackPlayer);
                View.DisplayPoints(BlackJackPlayer);
            }
        }

        public void HitCard()
        {
            int card = Random.Next(2, 12);
            GameHelper.AddAces(BlackJackPlayer, card);

            BlackJackPlayer.Images[BlackJackPlayer.CurrentImage].Source = ImageClass.RandomColorCard(CardImages.First(x => x.Key == card).Value);
            BlackJackPlayer.CurrentImage++;
            BlackJackPlayer.Score += card;

            if (BlackJackPlayer.Score > 21 && !GameHelper.HasAces(BlackJackPlayer))
            {
                BetPlaced = false;
                End(false);
            }
            View.DisplayPoints(BlackJackPlayer);
        }

        public void Stand(bool isSplit)
        {
            int cardOne = Random.Next(2, 12);
            int cardTwo = Random.Next(2, 12);
            GameHelper.AddAces(Computer, cardOne);
            GameHelper.AddAces(Computer, cardTwo);

            Computer.Images[0].Source =
                ImageClass.RandomColorCard(CardImages.First(x => x.Key == cardOne).Value);
            Computer.Images[1].Source =
                ImageClass.RandomColorCard(CardImages.First(x => x.Key == cardTwo).Value);

            Computer.Score = cardOne + cardTwo;
            View.DisplayPoints(Computer);

            if (Computer.Score < 17 || (Computer.Score > 21 && GameHelper.HasAces(Computer)))
            {
                TaskFactory = new TaskFactory(TaskScheduler.FromCurrentSynchronizationContext());
                new Thread(() => HitCardComputer(isSplit)).Start();
            }
            else
            {
                End(isSplit);
            }
            BetPlaced = false;
        }

        public void HitCardComputer(bool isSplit)
        {
            TaskFactory.StartNew(() => View.DealButton(false));
            while (Computer.Score < 17 && Computer.CurrentImage < Computer.Images.Count())
            {
                // Pretend to be thinking
                Thread.Sleep(1000);

                int card = Random.Next(2, 12);
                GameHelper.AddAces(Computer, card);

                Computer.Score += card;
                TaskFactory.StartNew((() => DisplayCard(card)));

                if (Computer.Score > 21)
                {
                    GameHelper.HasAces(Computer);
                }
            }
            TaskFactory.StartNew(() => End(isSplit));
            TaskFactory.StartNew(() => View.DealButton(true));
            Thread.Yield();
        }

        private void DisplayCard(int card)
        {
            Computer.Images[Computer.CurrentImage].Source =
                ImageClass.RandomColorCard(CardImages.First(x => x.Key == card).Value);
            Computer.CurrentImage++;
            View.DisplayPoints(Computer);
        }

        private void End(bool isSplit)
        {
            View.EndGame(BlackJackPlayer, Computer, Convert.ToInt16(BetAmount));
            View.DisplayMoney(BlackJackPlayer, Computer);
        }
    }
}
