﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeepCasinoProjekt
{
    public class Player
    {
        string name;
        int DeepCoins;

        public Player(string n, int c)
        {
            name = n;
            DeepCoins = c;
        }

        public string GetName()
        {
            return name;
        }

        public int GetChips()
        {
            return DeepCoins;
        }

        public void SetName(string n)
        {
            name = n;
        }

        public void SetChips(int c)
        {
            DeepCoins = c;
        }

        public void AddChips(int c)
        {
            DeepCoins += c;
        }
    }
}
