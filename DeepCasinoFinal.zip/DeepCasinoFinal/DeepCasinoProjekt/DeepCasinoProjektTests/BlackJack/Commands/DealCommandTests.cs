﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Blackjack.Commands.Tests
{
    [TestClass()]
    public class DealCommandTests
    {
        [TestMethod()]
        public void DealCommandTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void CanExecuteTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void ExecuteTest()
        {
            Assert.Fail();
        }
    }
}