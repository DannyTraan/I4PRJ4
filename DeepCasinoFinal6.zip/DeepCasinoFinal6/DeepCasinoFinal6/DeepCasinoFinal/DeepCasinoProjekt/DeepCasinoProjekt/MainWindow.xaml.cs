﻿using System.Windows;
using DeepCasinoProjekt.Roulette;

namespace DeepCasinoProjekt
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            ContentHolder.Content = new EntryWindow();

        }

        public void SetContent(Account p, int contentId)
        {
            switch (contentId)
            {
                case 0: ContentHolder.Content = new SelectGameWindow(p); break;
                case 1: ContentHolder.Content = new BlackJackWindow(p); break;
                case 2: ContentHolder.Content = new RouletteWindow(p); break;
            }
        }

        private void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            this.SizeToContent = SizeToContent.WidthAndHeight;
        }
    }
}
