﻿using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using DeepCasinoProjekt.BlackJack.Helpers;
using DeepCasinoProjekt.BlackJack.ViewModels;
using DeepCasinoProjekt.Interfaces;
using DeepCasinoProjekt.Models;

namespace DeepCasinoProjekt
{
    /// <summary>
    /// Interaction logic for BlackJackWindow.xaml
    /// </summary>
    public partial class BlackJackWindow : IView
    {
        readonly Account _account;
        private int mm;
        public BlackJackWindow(Account acc)
        {
            InitializeComponent();
            _account = acc;
            DataContext = new GameViewModel(this, acc);
            BetLabel.Content = "Place bet:";
        }

        public BlackJackWindow()
        {
            InitializeComponent();
            DataContext = new GameViewModel(this, _account);
        }

        public void AddCards(BlackJackPlayer pla, BlackJackPlayer cpu)
        {
            AddImages(pla, PlayerImages);
            AddImages(cpu, ComputerImages);
        }

        private void AddImages(BlackJackPlayer player, Grid grid)
        {
            for (var i = 0; i < VisualTreeHelper.GetChildrenCount(grid); i++)
            {
                var child = VisualTreeHelper.GetChild(grid, i);
                player.Images.Add((Image)child);
            }
        }

        public void DealButton(bool show)
        {
            Deal.Visibility = show ? Visibility.Visible : Visibility.Hidden;
        }

        public void DisplayName(string name)
        {
            Name1.Content = name + ":";
            Name2.Content = name + ":";
        }

        public void ShowResult(string result)
        {
            Result.Content = result;
        }

        public void ResetResult()
        {
            Result.Content = string.Empty;
            ComputerPoints.Content = 0;
            PlayerPoints.Content = 0;
        }

        public void DisplayMplay(BlackJackPlayer pla, BlackJackPlayer cpu)
        {
            PlayerMplay.Content = pla.DeepCoins;
            ComputerMplay.Content = cpu.DeepCoins;
        }

        public void DisplayPoints(BlackJackPlayer player)
        {
            if (player.Name == "Computer")
            {
                ComputerPoints.Content = player.Score;
            }
            else
            {
                PlayerPoints.Content = player.Score;
            }
        }

        public void EndGame(BlackJackPlayer pla, BlackJackPlayer cpu, int bet)
        {
            BlackJackPlayer winner = GameHelper.CalculateWinner(pla, cpu);
            if (winner == null)
            {
                ShowResult("DRAW!");
            }
            else
            {
                ShowResult(winner.Name + " WON!");
                if (winner == pla)
                {
                    pla.DeepCoins += bet;
                    cpu.DeepCoins -= bet;
                }
                else
                {
                    cpu.DeepCoins += bet;
                    pla.DeepCoins -= bet;
                }
            }

           
            DbSaver(pla.DeepCoins);
        }

        public void DbSaver(int mm)
        {
            //var con = new SqlConnection(@"Data Source=st-i4dab.uni.au.dk;Initial Catalog=E18I4DABau556770;User ID=E18I4DABau556770;Password=E18I4DABau556770;Connect Timeout=60;Encrypt=False;TrustServerCertificate=True;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
            //con.Open();





            //string updateString = @"UPDATE Player
            //                               SET Wallet = (@Wallet, UserName = @UserName, HighScore = @HighScore)
            //                               WHERE PlayerID = @PlayerID
            //                                VALUES ('"+mm+"','"+_account.GetName()+"','"+0+"')";



            //    using (SqlCommand cmd = new SqlCommand(updateString, con))
            //    {
            //        cmd.Parameters.AddWithValue("@Wallet", updateString);
            //        cmd.Parameters.AddWithValue("@UserName", updateString);
            //        cmd.Parameters.AddWithValue("@HighScore", updateString);
            //        cmd.Parameters.AddWithValue("@PlayerID", updateString);

            //        var id = (long)cmd.ExecuteNonQuery();
                
            //}
            //con.Close();

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
