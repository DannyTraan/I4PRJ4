﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;
using DeepCasinoProjekt.Roulette;
using DeepCasinoProjekt.Roulette.Models;
using NSubstitute;
using NUnit.Framework;

namespace DeepCasinoProjekt.Unit.Test
{
    [TestFixture]
    [Author("Semesterprojekt Gr. 2")]
    public class UpdateWalletTest
    {
        //Demand
        private string _userName;
        private int _userWallet;

        //uut
        private RoulettePlayer _uut;

        //Required

        [SetUp]
        public void Setup()
        {
            //Arrange
            _uut = new RoulettePlayer(_userName, _userWallet);

            _userName = "TestUser";
            _userWallet = 1000;
        }

        [Test]
        public void RouletteWindow_UpdateWalletKeepTrackOfCurrentValue()
        {
            if (_userWallet < 0)
            {
                Console.WriteLine("You do not have enough DeepCoins!");
            }
            else
            {
                Console.WriteLine("DeepCoins: " + _userWallet);
            }

            Assert.That(_userWallet.Equals(1000), Is.True);
        }
    }
}
