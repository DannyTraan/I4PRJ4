﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeepCasinoProjekt.Roulette.Models
{
    public class RoulettePlayer
    {
        public string Name { get; set; }
        public int DeepCoins { get; set; }

        public RoulettePlayer(string name, int deepCoins)
        {
            Name = name;
            DeepCoins = deepCoins;
        }
    }
}
