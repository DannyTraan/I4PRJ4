﻿using System;
using System.Windows.Input;
using DeepCasinoProjekt;
using DeepCasinoProjekt.BlackJack.ViewModels;
using DeepCasinoProjekt.Models;

namespace Blackjack.Commands
{
    public class DealCommand : ICommand
    {
        public event EventHandler CanExecuteChanged
        {
            add => CommandManager.RequerySuggested += value;
            remove => CommandManager.RequerySuggested -= value;
        }

        private readonly GameViewModel _viewModel;

        public DealCommand(GameViewModel viewModel)
        {
            this._viewModel = viewModel;
        }

        public bool CanExecute(object parameter)
        {
            if (_viewModel.BetPlaced)
            {
                return false;
            }

            bool parsed = int.TryParse(_viewModel.BetAmount, out var bet);

            if (parsed)
            {
                if (bet >= 1 && bet <= 500)
                {
                    return true;
                }            
            }
            return false;
        }

        public void Execute(object parameter)
        {
            _viewModel.DealCards();
        }
    }
}