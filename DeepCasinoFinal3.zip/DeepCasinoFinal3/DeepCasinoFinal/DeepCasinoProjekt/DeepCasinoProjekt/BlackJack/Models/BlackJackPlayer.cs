﻿using System.Collections.Generic;
using System.Windows.Media.Imaging;
using System.Windows.Controls;

namespace DeepCasinoProjekt.Models
{
    public class BlackJackPlayer
    {
        public List<Image> Images { get; set; }
        public BitmapImage ImageBack { get; set; }
        public string Name { get; set; }
        public int DeepCoins { get; set; }
        public int Score { get; set; }
        public int Aces { get; set; }
        public int CurrentImage { get; set; }

        public BlackJackPlayer(string name, int deepCoins, BitmapImage backSide, int currentImage)
        {
            Images = new List<Image>();
            Name = name;
            DeepCoins = deepCoins;
            ImageBack = backSide;
            CurrentImage = currentImage;
        }

        public void ShowBackside()
        {
            Images[0].Source = ImageBack;
            Images[1].Source = ImageBack;
        }

        public void Reset()
        {
            CurrentImage = 2;
            Aces = 0;
            Score = 0;
        }
    }
}

