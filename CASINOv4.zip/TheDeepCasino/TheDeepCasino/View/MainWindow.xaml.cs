﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using BlackjackWPF;


namespace TheDeepCasino.View
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            ContentHolder.Content = new EntryWindow();
        }

        public void SetContent(Account acc, int contentId)
        {
            switch (contentId)
            {
                case 0: ContentHolder.Content = new GamePicker(acc); break;
                case 1: ContentHolder.Content = new BJWindow(); break;
                //case 4: ContentHolder.Content = new RouletteScreen(p); break;
            }

        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            this.SizeToContent = SizeToContent.WidthAndHeight;
        }

        //private void standButton_Click(object sender, RoutedEventArgs e)
        //{
        //    SoundPlayer lan = new SoundPlayer(TheDeepCasino.Properties.Resources.clicksound);
        //    lan.Play();

        //}
    }
}
