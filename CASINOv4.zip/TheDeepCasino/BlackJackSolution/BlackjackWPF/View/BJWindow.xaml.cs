﻿using System.Windows;
using System;
using System.Media;
using System.IO;
using System.Windows.Controls;

namespace BlackjackWPF
{
    public partial class BJWindow : UserControl
    {
        public BJWindow()
        {
            InitializeComponent();
            //account = acc;
            //WelcomeLabel.Content = "Welcome " + acc.GetName() + ". Choose a game lan";
            //ChipsLabel.Content = "You have " + acc.GetChips() + " chips lan";
            //InitializeComponent();
        }

        private void Sound_Click(object sender, RoutedEventArgs e)
        {
            SoundPlayer lan = new SoundPlayer(BlackjackWPF.Properties.Resources.clicksound);
            lan.Play();
        }

    }
}