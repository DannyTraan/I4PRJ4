﻿using System.Collections.Generic;
using System.Linq;

namespace BlackjackWPF.Model
{
    public class Card
    {
        // Variables
        public VALUES Values { get; }
        public SUITS Suit { get; }

        // Constructor
        public Card(VALUES values, SUITS suit)
        {
            Values = values;
            Suit = suit;
        }

        public static readonly Dictionary<VALUES, int> CardRanks = new Dictionary<VALUES, int>()
        {
            { VALUES.Two, 2 },
            { VALUES.Three, 3 },
            { VALUES.Four, 4 },
            { VALUES.Five, 5 },
            { VALUES.Six, 6 },
            { VALUES.Seven, 7 },
            { VALUES.Eight, 8 },
            { VALUES.Nine, 9 },
            { VALUES.Ten, 10 },
            { VALUES.Jack, 10 },
            { VALUES.Queen, 10 },
            { VALUES.King, 10 },
            { VALUES.Ace, 11 },
            { VALUES.Blank, 12 },
            { VALUES.Unknown, 12 },
        };
        public static Card[] SortByValues(Card[] list)
        {
            return list.OrderBy(cCard => CardRanks[cCard.Values]).ToArray();
        }
    }
}
