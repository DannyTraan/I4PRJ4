﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Media.Imaging;
using DeepCasinoProjekt.BlackJack.Helpers;
using DeepCasinoProjekt.BlackJack.Models;
using DeepCasinoProjekt.Interfaces;
using DeepCasinoProjekt.Models;

namespace DeepCasinoProjekt.BlackJack.ViewModels
{
    public class GameViewModel 
    {
        public Commands Commands { get; }
        public Dictionary<int, BitmapImage[]> CardImages { get;}
        public BlackJackPlayer BlackJackPlayer { get; set; }
        public BlackJackPlayer Computer { get; set; }
        public TaskFactory TaskFactory { get; private set; }
        public IView View { get; set; }
        public string BetAmount { get; set; }
        public bool BetPlaced { get; set; }
        public Random Random { get; set; }

        public GameViewModel(IView view, Account acc1)
        {
            View = view;
            Random = new Random();
            Commands = new Commands(this);

            BlackJackPlayer = new BlackJackPlayer(acc1.GetName(), acc1.GetDeepCoins(), ImageHelper.CreateImage("Player"), 2);
            Computer = new BlackJackPlayer("Computer", acc1.GetDeepCoins(), ImageHelper.CreateImage("Computer"), 2);
            view.DisplayMplay(BlackJackPlayer, Computer);
            view.DisplayName(acc1.GetName());

            CardImages = ImageHelper.GetBlackJackCards();
            view.AddCards(BlackJackPlayer, Computer);
            BlackJackPlayer.ShowBackside();
            Computer.ShowBackside();
            BetAmount = "100";
        }

        public void DealCards()
        {
            // Reset the board
            GameHelper.ResetImages(BlackJackPlayer, Computer);
            GameHelper.ResetGame(BlackJackPlayer, Computer);
            View.ResetResult();
            BetPlaced = true;

            int cardpla = Random.Next(2, 12);
            int cardcpu = Random.Next(2, 12);
            GameHelper.AddAces(BlackJackPlayer, cardpla);
            GameHelper.AddAces(BlackJackPlayer, cardcpu);

            BlackJackPlayer.Images[0].Source = ImageHelper.RandomColorCard(CardImages.First(x => x.Key == cardpla).Value);
            BlackJackPlayer.Images[1].Source = ImageHelper.RandomColorCard(CardImages.First(x => x.Key == cardcpu).Value);
            BlackJackPlayer.Score = cardpla + cardcpu;
            View.DisplayPoints(BlackJackPlayer);

            if (BlackJackPlayer.Score > 21)
            {
                GameHelper.HasAces(BlackJackPlayer);
                View.DisplayPoints(BlackJackPlayer);
            }
        }

        public void HitCard()
        {
            int card = Random.Next(2, 12);
            GameHelper.AddAces(BlackJackPlayer, card);

            BlackJackPlayer.Images[BlackJackPlayer.CurrentImage].Source = ImageHelper.RandomColorCard(CardImages.First(x => x.Key == card).Value);
            BlackJackPlayer.CurrentImage++;
            BlackJackPlayer.Score += card;

            if (BlackJackPlayer.Score > 21 && !GameHelper.HasAces(BlackJackPlayer))
            {
                BetPlaced = false;
                End();
            }
            View.DisplayPoints(BlackJackPlayer);
        }

        public void Stand()
        {
            int cardpla = Random.Next(2, 12);
            int cardcpu = Random.Next(2, 12);
            GameHelper.AddAces(Computer, cardpla);
            GameHelper.AddAces(Computer, cardcpu);

            Computer.Images[0].Source =
                ImageHelper.RandomColorCard(CardImages.First(x => x.Key == cardpla).Value);
            Computer.Images[1].Source =
                ImageHelper.RandomColorCard(CardImages.First(x => x.Key == cardcpu).Value);

            Computer.Score = cardpla + cardcpu;
            View.DisplayPoints(Computer);

            if (Computer.Score < 17 || (Computer.Score > 21 && GameHelper.HasAces(Computer)))
            {
                TaskFactory = new TaskFactory(TaskScheduler.FromCurrentSynchronizationContext());
                new Thread(() => HitCardComputer( )).Start();
            }
            else
            {
                End( );
            }
            BetPlaced = false;
        }

        public void HitCardComputer()
        {
            TaskFactory.StartNew(() => View.DealButton(false));
            while (Computer.Score < 17 && Computer.CurrentImage < Computer.Images.Count())
            {
                // Pretend to be thinking
                Thread.Sleep(1000);

                int card = Random.Next(2, 12);
                GameHelper.AddAces(Computer, card);

                Computer.Score += card;
                TaskFactory.StartNew((() => DisplayCard(card)));

                if (Computer.Score > 21)
                {
                    GameHelper.HasAces(Computer);
                }
            }
            TaskFactory.StartNew(() => End( ));
            TaskFactory.StartNew(() => View.DealButton(true));
            Thread.Yield();
        }

        private void DisplayCard(int card)
        {
            Computer.Images[Computer.CurrentImage].Source =
                ImageHelper.RandomColorCard(CardImages.First(x => x.Key == card).Value);
            Computer.CurrentImage++;
            View.DisplayPoints(Computer);
        }

        private void End()
        {
            View.EndGame(BlackJackPlayer, Computer, Convert.ToInt16(BetAmount));
            View.DisplayMplay(BlackJackPlayer, Computer);
        }
    }
}
