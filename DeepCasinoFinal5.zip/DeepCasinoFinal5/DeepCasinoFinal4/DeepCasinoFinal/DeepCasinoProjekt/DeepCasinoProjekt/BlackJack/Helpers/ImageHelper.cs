﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Media.Imaging;

namespace DeepCasinoProjekt.BlackJack.Helpers
{
    public class ImageHelper
    {
        public static BitmapImage RandomColorCard(BitmapImage[] images)
        {
            Random ran = new Random();
            return images[ran.Next(0, images.Count())];
        }

        public static BitmapImage CreateImage(string imageName)
        {
            return new BitmapImage(new Uri("/Images/" + imageName + ".png", UriKind.Relative));
        }

        public static Dictionary<int, BitmapImage[]> GetBlackJackCards()
        {
            Dictionary<int, BitmapImage[]> images = new Dictionary<int, BitmapImage[]>();

            images.Add(2, CreateImagesArray(CreateImage("h2"), CreateImage("kløver2"), CreateImage("d2"), CreateImage("s2")));
            images.Add(3, CreateImagesArray(CreateImage("h3"), CreateImage("kløver3"), CreateImage("d3"), CreateImage("s3")));
            images.Add(4, CreateImagesArray(CreateImage("h4"), CreateImage("kløver4"), CreateImage("d4"), CreateImage("s4")));
            images.Add(5, CreateImagesArray(CreateImage("h5"), CreateImage("kløver5"), CreateImage("d5"), CreateImage("s5")));
            images.Add(6, CreateImagesArray(CreateImage("h6"), CreateImage("kløver6"), CreateImage("d6"), CreateImage("s6")));
            images.Add(7, CreateImagesArray(CreateImage("h7"), CreateImage("kløver7"), CreateImage("d7"), CreateImage("s7")));
            images.Add(8, CreateImagesArray(CreateImage("h8"), CreateImage("kløver8"), CreateImage("d8"), CreateImage("s8")));
            images.Add(9, CreateImagesArray(CreateImage("h9"), CreateImage("kløver9"), CreateImage("d9"), CreateImage("s9")));
            images.Add(11, CreateImagesArray(CreateImage("h1"), CreateImage("kløver1"), CreateImage("d1"), CreateImage("s1")));

            images.Add(10, new BitmapImage[16] {
                CreateImage("h10"), CreateImage("kløver10"), CreateImage("d10"), CreateImage("s10"), CreateImage("hj"), CreateImage("kløverj"),
                CreateImage("dj"), CreateImage("sj"), CreateImage("hq"), CreateImage("kløverq"), CreateImage("dq"), CreateImage("sq"),
                CreateImage("hk"), CreateImage("kløverk"), CreateImage("dk"), CreateImage("sk") });

            return images;
        }

        private static BitmapImage[] CreateImagesArray(BitmapImage one, BitmapImage two, BitmapImage three, BitmapImage four)
        {
            return new BitmapImage[4] { one, two, three, four };
        }
    }
}
