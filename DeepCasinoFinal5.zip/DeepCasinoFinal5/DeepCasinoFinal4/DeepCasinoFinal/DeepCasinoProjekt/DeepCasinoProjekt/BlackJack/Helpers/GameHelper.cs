﻿using DeepCasinoProjekt.Models;

namespace DeepCasinoProjekt.BlackJack.Helpers
{
    public class GameHelper
    {
        public static void AddAces(BlackJackPlayer Account, int card)
        {
            if (card == 11)
            {
                Account.Aces++;
            }
        }

        public static BlackJackPlayer CalculateWinner(BlackJackPlayer pla, BlackJackPlayer cpu)
        {
            if ((pla.Score > cpu.Score || cpu.Score > 21) && pla.Score <= 21)
            {
                return pla;
            }
            if ((cpu.Score > pla.Score || pla.Score > 21) && cpu.Score <= 21)
            {
                return cpu;
            }

            return null;
        }

        public static bool HasAces(BlackJackPlayer Account)
        {
            if (Account.Aces > 0)
            {
                Account.Aces--;
                Account.Score -= 10;
                return true;
            }

            return false;
        }

        public static void ResetGame(BlackJackPlayer pla, BlackJackPlayer cpu)
        {
            pla.Reset();
            cpu.Reset();
        }

        public static void ResetImages(BlackJackPlayer pla, BlackJackPlayer cpu)
        {
            pla.Images.ForEach(x => x.Source = null);
            cpu.Images.ForEach(x => x.Source = null);

            cpu.Images[0].Source = cpu.ImageBack;
            cpu.Images[1].Source = cpu.ImageBack;
        }
    }
}
