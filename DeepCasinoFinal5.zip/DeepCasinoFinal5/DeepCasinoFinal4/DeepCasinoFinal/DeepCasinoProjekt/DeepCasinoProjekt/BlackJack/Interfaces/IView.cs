﻿using DeepCasinoProjekt.Models;

namespace DeepCasinoProjekt.Interfaces
{
    public interface IView
    {
        void AddCards(BlackJackPlayer pla, BlackJackPlayer cpu);
        void DealButton(bool show);
        void DisplayName(string name);
        void ResetResult();
        void DisplayMplay(BlackJackPlayer pla, BlackJackPlayer cpu);
        void DisplayPoints(BlackJackPlayer Account);
        void EndGame(BlackJackPlayer pla, BlackJackPlayer cpu, int bet);
    }
}
