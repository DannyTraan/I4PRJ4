﻿namespace BlackjackWPF.Model
{
    public enum VALUES
    {
        Blank,
        Unknown,
        Two,
        Three,
        Four,
        Five,
        Six,
        Seven,
        Eight ,
        Nine ,
        Ten,
        Jack ,
        Queen,
        King ,
       Ace,
    };
}
