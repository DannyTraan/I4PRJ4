﻿namespace BlackjackWPF.Model
{
    public enum SUITS
    {
        Blank,
        Unknown,
        Clubs,
        Spades,
        Hearts,
        Diamonds,
    }
}
