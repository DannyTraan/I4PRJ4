﻿using System.Collections.Generic;
using System.Linq;

namespace BlackjackWPF.Model
{
    public abstract class BasePlayer : States
    {

        public delegate void HandChangedEventHandler(object sender, HandEventArgs args);

        public event HandChangedEventHandler HandChanged;

        public abstract BlackjackGame.ACTIONS GetAction();

        #region Methods definition

        //Tilføjer kort til spillers hånd
        public void AddCardToHand(Card currentCard)
        {
            int blanks = (from Card checkCard in CurrentHand
                               where checkCard.Values == VALUES.Blank ||
                               checkCard.Suit == SUITS.Blank
                               select checkCard).Count();

            if (blanks >= 1 || CurrentHand.Count() != CurrentHand.Length - blanks)
            {
                if (currentCard.Values ==VALUES.Blank || currentCard.Suit == SUITS.Blank || !CurrentHand.Contains(currentCard))
                {
                    for (int i = 0; i < CurrentHand.Length; i++)
                    {
                        if (CurrentHand[i].Values == VALUES.Blank || CurrentHand[i].Suit == SUITS.Unknown)
                        {
                            CurrentHand[i] = currentCard;
                            TrigHandChanged(new HandEventArgs(i, currentCard));
                            return;
                        }
                    }
                }
            }
        }


        //Returner den totale værdi af objekts hånd.
        public int GetHandTotal()
        {
            int totalValue = 0;
            foreach (Card CurrentCard in Card.SortByValues(CurrentHand))
            {
                if (CurrentCard.Values == VALUES.Ace)
                {
                    //Hvis nuværende kort er et ace, så kan det enten være 11 eller 1 afhængigt af hvad spiller har i sin hånd
                    if ((totalValue + 11) > 21)
                    {
                        totalValue += 1;
                    }
                    else
                    {
                        totalValue += 11;
                    }
                }
                else if (CurrentCard.Values == VALUES.Blank || CurrentCard.Values == VALUES.Unknown || CurrentCard.Suit == SUITS.Blank || CurrentCard.Suit == SUITS.Unknown)
                {
                    totalValue += 0;
                }
                else
                {
                    totalValue += Card.CardRanks[CurrentCard.Values];
                }
            }

            return totalValue;
        }


        // Returner det objekts nuværende hånd og reseter member. 
        public List<Card> ReturnCards()
        {
            List<Card> tempList = CurrentHand.ToList<Card>();
            List<Card> returnCardList = new List<Card>();
            foreach (Card c in tempList)
            {
                if (!(c.Values == VALUES.Unknown || c.Values == VALUES.Blank || c.Suit == SUITS.Unknown || c.Suit == SUITS.Blank))
                {
                    returnCardList.Add(c);
                }
            }
            BlankingHand();

            return returnCardList;
        }
        

        //Sætter hver kort i dette objekts hånd til at være et blankt kort.
        public void BlankingHand()
        {
            for (int i = 0; i < CurrentHand.Length; i++)
            {
                Card blankCard = new Card(VALUES.Blank, SUITS.Blank);
                CurrentHand[i] = blankCard;
                TrigHandChanged(new HandEventArgs(i, blankCard));
            }
        }


        //Hånd har ændret sig 
        protected virtual void TrigHandChanged(HandEventArgs args)
        {
            HandChanged?.Invoke(this, args);
        }
        #endregion
    }

}
