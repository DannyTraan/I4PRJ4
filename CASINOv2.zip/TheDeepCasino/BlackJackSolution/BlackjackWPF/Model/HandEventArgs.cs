﻿namespace BlackjackWPF.Model
{
    public class HandEventArgs 
    {

        public int Index { get; }
        public Card Card { get; }

        public HandEventArgs(int index, Card card)
        {
            Index = index;
            Card = card;
        }

    }
}
