﻿//namespace BlackjackWPF.Model
//{
//    public abstract class Game
//    {
//        protected Deck cardDeck;
//        public Deck CardDeck => cardDeck;
//    }
//}
