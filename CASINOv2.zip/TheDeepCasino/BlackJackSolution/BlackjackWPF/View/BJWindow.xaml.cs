﻿using System.Windows;
using System;
using System.Media;
using System.IO;

namespace BlackjackWPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public class BJWindow : Window
    {
        public BJWindow()
        {
            //InitializeComponent();
        }

        //private void standButton_Click(object sender, RoutedEventArgs e)
        //{
        //    SoundPlayer lan = new SoundPlayer(BlackjackWPF.Properties.Resources.clicksound);
        //    lan.Play();
        //}

    }
}