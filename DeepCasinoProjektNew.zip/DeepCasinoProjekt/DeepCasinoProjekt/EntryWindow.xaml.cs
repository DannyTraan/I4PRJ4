﻿using System.Data.SqlClient;
using System.Media;
using System.Windows;
using System.Windows.Controls;


namespace DeepCasinoProjekt
{
    /// <summary>
    /// Interaction logic for EntryWindow.xaml
    /// </summary>
    public partial class EntryWindow : UserControl
    {
        SoundPlayer SP = new SoundPlayer(DeepCasinoProjekt.Properties.Resources.clicksound);
        public EntryWindow()
        {
            InitializeComponent();
        }

        private void StartButton_Click(object sender, RoutedEventArgs e)
        {
            string name = lestdoit.Text;
            SP.Play();

            MainWindow window = (MainWindow)Window.GetWindow(this);
            window.SetContent(new Account(name, 1000), 0);
            
            var con = new SqlConnection(@"Data Source=st-i4dab.uni.au.dk;Initial Catalog=E18I4DABau556770;User ID=E18I4DABau556770;Password=E18I4DABau556770;Connect Timeout=60;Encrypt=False;TrustServerCertificate=True;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
            con.Open();


            var query = "INSERT Player (HighScore, UserName, Wallet) VALUES (0,'"+this.lestdoit.Text+"',1000)";

            SqlCommand cmd = new SqlCommand(query,con);

                  cmd.ExecuteNonQuery();
            con.Close();
        }

  
    }
}
