﻿using System.Media;
using System.Windows;
using System.Windows.Controls;

namespace DeepCasinoProjekt
{
    /// <summary>
    /// Interaction logic for SelectGameWindow.xaml
    /// </summary>
    public partial class SelectGameWindow : UserControl
    {
        SoundPlayer SP = new SoundPlayer(DeepCasinoProjekt.Properties.Resources.clicksound);

        public SelectGameWindow()
        {
            InitializeComponent();
        }

        Account Account;

        public SelectGameWindow(Account p)
        {
            InitializeComponent();
            Account = p;
            WelcomeLabel.Content = "Welcome " + p.GetName() + "! Which game would you like to play?";
            ChipsLabel.Content = "You currently have " + p.GetDeepCoins() + " DeepCoins.";
        }

        private void BlackjackButton_Click(object sender, RoutedEventArgs e)
        {
            SP.Play();

            MainWindow window = (MainWindow)Window.GetWindow(this);
            window.SetContent(Account, 1);
        }

        private void RouletteButton_Click(object sender, RoutedEventArgs e)
        {
            SP.Play();

            MainWindow window = (MainWindow)Window.GetWindow(this);
            window.SetContent(Account, 2);
        }

        private void ReloadButton_Click(object sender, RoutedEventArgs e)
        {
            SP.Play();

            Account.SetDeepCoins(500);
            ChipsLabel.Content = "You have " + Account.GetDeepCoins() + " DeepCoins.";
        }

        private void ShopButton_OnClick_Click(object sender, RoutedEventArgs e)
        {
            SP.Play();

            MainWindow window = (MainWindow)Window.GetWindow(this);
            window.SetContent(Account, 3);
        }
    }
}
