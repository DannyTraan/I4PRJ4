﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DeepCasinoProjekt
{
    /// <summary>
    /// Interaction logic for ShopWindow.xaml
    /// </summary>
    public partial class ShopWindow : UserControl
    {
        SoundPlayer SP = new SoundPlayer(DeepCasinoProjekt.Properties.Resources.clicksound);
        Account _account;
        public ShopWindow()
        {
            InitializeComponent();
        }

        public ShopWindow(Account acc)
        {
            InitializeComponent();
            _account = acc;

        }

        private void Car_Click(object sender, RoutedEventArgs e)
        {
            SP.Play();
            _account.SetDeepCoins(_account.GetDeepCoins()-1999999); 
        }

        private void Teddy_Click(object sender, RoutedEventArgs e)
        {
            SP.Play();
            _account.SetDeepCoins(_account.GetDeepCoins() - 2999);
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            _account.GetDeepCoins();
            SP.Play();

            MainWindow window = (MainWindow)Window.GetWindow(this);
            window.SetContent(_account, 0);
        }
    }
}
