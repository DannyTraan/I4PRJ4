﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DeepCasinoProjekt.Roulette.Models;
using NUnit.Framework;

namespace DeepCasinoProjekt.Unit.Test.Roulette.Unit.Test
{
    [TestFixture]
    [Author("Semesterprojekt Gr. 2")]
    public class BetTest
    {
        //Demand
        private string _userName;
        private int _userWallet;

        //uut
        private RoulettePlayer _uut;

        //Required
        private int _bet;

        [SetUp]
        public void Setup()
        {
            //Arrange
            _uut = new RoulettePlayer(_userName, _userWallet);

            _userName = "TestUser";
            _userWallet = 1000;

            _bet = 5;
        }

        [Test]
        public void Bet_BetOnFiveSubtractsFiveFromWallet()
        {
            if (_bet < _userWallet)
            {
                _userWallet -= _bet;
            }

            Assert.That(_userWallet.Equals(995), Is.True);
        }
    }
}
