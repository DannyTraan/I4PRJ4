﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeepCasinoProjekt.Roulette.Interfaces
{
    public interface IRouletteWindow
    {
        void UpdateWallet();
        void Bet();
        int GetBet();
        void WinOrLose();
    }
}
