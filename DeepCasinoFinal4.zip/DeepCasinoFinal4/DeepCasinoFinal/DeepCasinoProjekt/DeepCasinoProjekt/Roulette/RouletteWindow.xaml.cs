﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using DeepCasinoProjekt.Roulette.Interfaces;
using DeepCasinoProjekt.Roulette.Models;

namespace DeepCasinoProjekt.Roulette
{
    /// <summary>
    /// Interaction logic for RouletteWindow.xaml
    /// </summary>
    public partial class RouletteWindow : UserControl, IRouletteWindow
    {
        #region Wheel
        private static readonly int[] Green = new int[]
        {
            0
        };
        private static readonly int[] Reds = new int[]
        {
            32, 19, 21, 25, 34, 27, 36, 30, 23, 5, 16, 1, 14, 9, 18, 7, 12, 3
        };

        private static readonly int[] Blacks = new int[]
        {
            15, 4, 2, 17, 6, 13, 11, 8, 10, 24, 33, 20, 31, 22, 29, 28, 35, 26  
        };

        #endregion

        private readonly Random _wheel = new Random();
        private int _spin;
        private int _wallet;
        private int _bet;

        public RoulettePlayer RoulettePlayer { get; set; }

        readonly Account _account;

        public RouletteWindow(Account acc)
        {
            _account = acc;
            InitializeComponent();

            RoulettePlayer = new RoulettePlayer(acc.GetName(), acc.GetDeepCoins());
            _wallet += _account.GetDeepCoins();
            UpdateWallet();
        }

        private void spinButton_Click(object sender, RoutedEventArgs e)
        {
           _spin = _wheel.Next(0, 37);
            SpinLabel.Content = "You landed " + _spin;

            EmptyWalletLabel.Content = "";
            WinOrLose();
            UpdateWallet();
        }

        public void UpdateWallet()
        {
            if (_wallet < 0)
            {
                EmptyWalletLabel.Content = "You do not have enough DeepCoins!";
            }
            else
                WalletLabel.Content = "DeepCoins: " + _wallet;
            
        }

        public void Bet()
        {
            _bet = GetBet();
            if (_bet <= _account.GetDeepCoins())
            {
                _account.AddDeepCoins(-_bet);
                UpdateWallet();
            }
        }

        public int GetBet()
        {
            if (FiveBtn.IsChecked == true) return 5;
            if (TenBtn.IsChecked == true) return 10;
            if (FiftyBtn.IsChecked == true) return 50;
            if (HundredBtn.IsChecked == true) return 100;
            return 0;
        }

        public void WinOrLose()
        {
            Bet();
            if (EvenBtn.IsChecked == true)
            {
                if (_spin % 2 == 0)
                {
                    ResultLabel.Content = "You won on Even Numbers!";
                    _wallet += _bet * 2;
                }
                else
                {
                    ResultLabel.Content = "You lose on Even Numbers!";
                    _wallet -= _bet;
                }
            }

            if (OddBtn.IsChecked == true)
            {
                if (_spin % 2 != 0)
                {
                    ResultLabel.Content = "You won on Odd Numbers!";
                    _wallet += _bet * 2;
                }
                else
                {
                    ResultLabel.Content = "You lost on Odd Numbers!";
                    _wallet -= _bet;
                }
            }

            if (BlackBtn.IsChecked == true)
            {
                if (Blacks.Contains(_spin))
                {
                    ResultLabel.Content = "You won on Black!";
                    _wallet += _bet * 2;
                }
                else
                {
                    ResultLabel.Content = "You lost on Black!";
                    _wallet -= _bet;
                }
            }

            if (RedBtn.IsChecked == true)
            {
                if (Reds.Contains(_spin))
                {
                    ResultLabel.Content = "You won on Red!";
                    _wallet += _bet * 2;
                }
                else
                {
                    ResultLabel.Content = "You lost on Red!";
                    _wallet -= _bet;
                }
            }

            if (GreenBtn.IsChecked == true)
            {
                if (Green.Contains(_spin))
                {
                    ResultLabel.Content = "You won on Green!";
                    _wallet += _bet * 36;
                }
                else
                {
                    ResultLabel.Content = "You lost on Green!";
                    _wallet -= _bet * 18;
                }
            }
            UpdateWallet();
        }
    }
}
