﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeepCasinoProjekt
{
    public class Account
    {
        private string _name;
        private int _deepCoins;

        public Account(string n, int c)
        {
            _name = n;
            _deepCoins = c;
        }

        public string GetName()
        {
            return _name;
        }

        public int GetDeepCoins()
        {
            return _deepCoins;
        }

        public void SetName(string n)
        {
            _name = n;
        }

        public void SetDeepCoins(int c)
        {
            _deepCoins = c;
        }

        public void AddDeepCoins(int c)
        {
            _deepCoins += c;
        }
    }
}
