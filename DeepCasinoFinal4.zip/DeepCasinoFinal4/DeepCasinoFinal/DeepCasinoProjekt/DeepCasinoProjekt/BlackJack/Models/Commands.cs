﻿using System.Windows.Input;
using Blackjack.Commands;
using DeepCasinoProjekt.BlackJack.ViewModels;

namespace DeepCasinoProjekt.BlackJack.Models
{
    public class Commands
    {
        public ICommand DealCommand { get; }
        public ICommand HitCommand { get; }
        public ICommand StandCommand { get; }


        public Commands(GameViewModel viewModel)
        {
            DealCommand = new DealCommand(viewModel);
            HitCommand = new HitCommand(viewModel);
            StandCommand = new StandCommand(viewModel);
        }
    }
}
