﻿using System;
using System.ComponentModel;
using System.Windows.Input;
using System.Windows;
using BlackjackWPF.Model;
using System.Windows.Media;
using System.Collections.Generic;
using System.Collections.ObjectModel;


namespace BlackjackWPF.ViewModel
{
    public class MainWindowViewModel : INotifyPropertyChanged
    {

        #region Static members definition
        public enum LABELS { Wins, Ties, Losses };
        public enum PLAYERS { Dealer, Player };

        public const string WINS_DISPLAY_LABEL = "Wins: ";
        public const string TIES_DISPLAY_LABEL = "Ties: ";
        public const string LOSSES_DISPLAY_LABEL = "Losses: ";
        public const string PLAYER_WIN_STATUS_TEXT = "YOU WIN!";
        public const string DEALER_WIN_STATUS_TEXT = "DEALER WINS!";
        public const string TIE_STATUS_TEXT = "TIE!";
        public const string PLAYER_HEADER_TEXT = "Your Hand: {0}";
        public const string PLAYER_HIDDEN_HEADER_TEXT = "Your Hand";
        public const string DEALER_HEADER_TEXT = "Dealer's Hand: {0}";
        public const string DEALER_HIDDEN_HEADER_TEXT = "Dealer's Hand";
        #endregion

        #region INotifyPropertyChanged implementation
        public event PropertyChangedEventHandler PropertyChanged;
        #endregion

        #region properties

        public AsyncObservableCollection<VMCard> DealerCardsList { get; set; }
        public AsyncObservableCollection<VMCard> PlayerCardsList { get; set; }
        public string WinsDisplay { get; set; }
        public string TiesDisplay { get; set; }
        public string LossesDisplay { get; set; }
        public Visibility IsStartVisible { get; set; }
        public bool IsStartEnabled { get; set; }
        public bool IsStandReady { get; set; }
        public bool IsHitReady { get; set; }

        public bool IsInputReady
        {
            get { return (IsStandReady && IsHitReady); }
            set
            {
                IsStandReady = value;
                RaisePropertyChanged(nameof(IsStandReady));
                IsHitReady = value;
                RaisePropertyChanged(nameof(IsHitReady));
            }
        }
        public Visibility IsRestartVisible { get; set; }
        public bool IsRestartEnabled { get; set; }
        public Visibility IsResetVisible { get; set; }
        public bool IsResetEnabled { get; set; }
        public Visibility IsDisplayLabelVisible { get; set; }
        public Brush DealerBorderColor { get; set; }
        public Brush PlayerBorderColor { get; set; }
        public BlackjackGame BlackjackGame { get; set; }
        public string StatusLabelText { get; set; }
        public string DealerBoxHeader { get; set; }
        public string PlayerBoxHeader { get; set; }

        #endregion
       

        #region Commands
        private ICommand startupCommand;
        public ICommand StartupCommand => startupCommand ?? (startupCommand = new NoParamRelayCommand<object>(() => { RunStartupActions(); }));


        private ICommand startGameCommand;
        public ICommand StartGameCommand => startGameCommand ?? (startGameCommand = new NoParamRelayCommand<string>(StartGame));


        private ICommand hitCommand;
        public ICommand HitCommand => hitCommand ?? (hitCommand = new NoParamRelayCommand<string>(DoPlayerHit));


        private ICommand standCommand;
        public ICommand StandCommand => standCommand ?? (standCommand = new NoParamRelayCommand<string>(DoPlayerStand));

        private ICommand restartGameCommand;
        public ICommand RestartGameCommand => restartGameCommand ?? (restartGameCommand = new NoParamRelayCommand<string>(RestartGame));     

        private ICommand resetGameCommand;
        public ICommand ResetGameCommand => resetGameCommand ?? (resetGameCommand = new NoParamRelayCommand<string>(ResetGame));
        #endregion


        #region Methods definition
        private void RunStartupActions()
        {
            DealerCardsList = new AsyncObservableCollection<VMCard>()
                {

                    new VMCard(),
                    new VMCard(),
                    new VMCard(),
                    new VMCard(),
                    new VMCard(),
                    new VMCard(),
                    new VMCard()

              };
            RaisePropertyChanged("DealerCardsList");

            PlayerCardsList = new AsyncObservableCollection<VMCard>()
            {
                new VMCard(),
                new VMCard(),
                new VMCard(),
                new VMCard(),
                new VMCard(),
                new VMCard(),
                new VMCard(),
            };
            RaisePropertyChanged("PlayerCardsList");

            ChangeDisplayLabel(0, LABELS.Wins);
            ChangeDisplayLabel(0, LABELS.Ties);
            ChangeDisplayLabel(0, LABELS.Losses);

           IsResetEnabled = false;
            RaisePropertyChanged(nameof(IsResetEnabled));
            IsResetVisible = Visibility.Hidden;
            RaisePropertyChanged(nameof(IsResetVisible));
            IsRestartEnabled = false;
            RaisePropertyChanged("IsRestartEnabled");
            IsRestartVisible = Visibility.Hidden;
            RaisePropertyChanged("IsRestartVisible");
            IsStartEnabled = true;
            RaisePropertyChanged("IsStartEnabled");
           IsStartVisible = Visibility.Visible;
            RaisePropertyChanged("IsStartVisible");
            IsDisplayLabelVisible = Visibility.Hidden;
            RaisePropertyChanged(nameof(IsDisplayLabelVisible));
            IsInputReady = false;
            RaisePropertyChanged("IsInputReady");

            ChangeTotalLabel(0, PLAYERS.Dealer);
            ChangeTotalLabel(0, PLAYERS.Player);
        }

        private void StartGame()
        {
            IsStartEnabled = false;
            RaisePropertyChanged("IsStartEnabled");
            IsStartVisible = Visibility.Hidden;
            RaisePropertyChanged("IsStartVisible");
            IsDisplayLabelVisible = Visibility.Visible;
            RaisePropertyChanged(nameof(IsDisplayLabelVisible));
            IsResetEnabled = true;
            RaisePropertyChanged(nameof(IsResetEnabled));
            IsResetVisible = Visibility.Visible;
            RaisePropertyChanged(nameof(IsResetVisible));

            ChangeTotalLabel(0, PLAYERS.Dealer);
            ChangeTotalLabel(0, PLAYERS.Player);
            StatusLabelText = "";
            RaisePropertyChanged(nameof(StatusLabelText));

            if (BlackjackGame == null)
            {
               BlackjackGame = new BlackjackGame();
                BlackjackGame.SetDealer(new Dealer());
                BlackjackGame.Dealer.HandChanged += UpdateHands;
                BlackjackGame.SetPlayer(new Player());
                BlackjackGame.Player.HandChanged += UpdateHands;
            }

            BlackjackGame.DistributeHands();

            if (BlackjackGame.Player.GetHandTotal() == 21)
            {
                // Player got natural 21.
                IsResetEnabled = false;
                RaisePropertyChanged(nameof(IsResetEnabled));
                IsResetVisible = Visibility.Hidden;
                RaisePropertyChanged(nameof(IsResetVisible));
             IsRestartEnabled = true;
                RaisePropertyChanged(nameof(IsRestartEnabled));
                IsRestartVisible = Visibility.Visible;
                RaisePropertyChanged(nameof(IsRestartVisible));
                IsDisplayLabelVisible = Visibility.Hidden;
                RaisePropertyChanged(nameof(IsDisplayLabelVisible));
                IsInputReady = false;
                RaisePropertyChanged(nameof(IsInputReady));

               PlayerBorderColor = Brushes.DeepSkyBlue;
                RaisePropertyChanged(nameof(PlayerBorderColor));
                BlackjackGame.Player.Wins++;
                ChangeDisplayLabel(BlackjackGame.Player.Wins, LABELS.Wins);
                StatusLabelText = PLAYER_WIN_STATUS_TEXT;
                RaisePropertyChanged(nameof(StatusLabelText));

                DisplayDealerHand();
            }
            else
            {
                IsInputReady = true;
                RaisePropertyChanged("IsInputReady");
            }
        }

        private void DoPlayerHit()
        {
            IsInputReady = false;
            RaisePropertyChanged("IsInputReady");

            if (BlackjackGame.ActingPlayer == BlackjackGame.Player)
            {
                BlackjackGame.DoPlayerAction(BlackjackGame.ACTIONS.Hit);
            }

            if (BlackjackGame.Player.IsBusted)
            {
                DealerBorderColor = Brushes.DeepSkyBlue;
                RaisePropertyChanged(nameof(DealerBorderColor));
             BlackjackGame.Player.Losses++;
                ChangeDisplayLabel(BlackjackGame.Player.Losses, LABELS.Losses);
               StatusLabelText = DEALER_WIN_STATUS_TEXT;
                RaisePropertyChanged(nameof(StatusLabelText));
              IsInputReady = false;
                RaisePropertyChanged("IsInputReady");
               IsResetEnabled = false;
                RaisePropertyChanged(nameof(IsResetEnabled));
                IsResetVisible = Visibility.Hidden;
                RaisePropertyChanged(nameof(IsResetVisible));
                IsDisplayLabelVisible = Visibility.Hidden;
                RaisePropertyChanged(nameof(IsDisplayLabelVisible));
                IsRestartEnabled = true;
                RaisePropertyChanged(nameof(IsRestartEnabled));
                IsRestartVisible = Visibility.Visible;
                RaisePropertyChanged(nameof(IsRestartVisible));

                DisplayDealerHand();
            }
            else
            {
               IsInputReady = true;
                RaisePropertyChanged("IsInputReady");
            }
        }

        private void DoPlayerStand()
        {
            IsInputReady = false;
            RaisePropertyChanged(nameof(IsInputReady));

            BlackjackGame.ActingPlayer = BlackjackGame.Dealer;

            if (BlackjackGame.Dealer.GetHandTotal() <= BlackjackGame.Player.GetHandTotal())
            {
                do
                {
                    BlackjackGame.DoDealerAction();
                } while (BlackjackGame.ActingPlayer == BlackjackGame.Dealer);
            }

            if (BlackjackGame.Dealer.IsBusted && !BlackjackGame.Player.IsBusted)
            {
                PlayerBorderColor = Brushes.DeepSkyBlue;
                RaisePropertyChanged(nameof(PlayerBorderColor));
                BlackjackGame.Player.Wins++;
                ChangeDisplayLabel(BlackjackGame.Player.Wins, LABELS.Wins);
                StatusLabelText = PLAYER_WIN_STATUS_TEXT;
                RaisePropertyChanged(nameof(StatusLabelText));
            }
            else
            {
                BasePlayer winner = BlackjackGame.GetWinner();
                if (winner == null)
                {
                    // It was a tie.
                    DealerBorderColor = Brushes.DeepSkyBlue;
                    RaisePropertyChanged(nameof(DealerBorderColor));
                    PlayerBorderColor = Brushes.DeepSkyBlue;
                    RaisePropertyChanged(nameof(PlayerBorderColor));
                    StatusLabelText = TIE_STATUS_TEXT;
                    RaisePropertyChanged(nameof(StatusLabelText));
                    BlackjackGame.Player.Ties++;
                    ChangeDisplayLabel(BlackjackGame.Player.Ties, LABELS.Ties);
                }
                else if (winner == BlackjackGame.Player)
                {
                    // player won.
                    PlayerBorderColor = Brushes.DeepSkyBlue;
                    RaisePropertyChanged(nameof(PlayerBorderColor));
                    BlackjackGame.Player.Wins++;
                    ChangeDisplayLabel(BlackjackGame.Player.Wins, LABELS.Wins);
                    StatusLabelText = PLAYER_WIN_STATUS_TEXT;
                    RaisePropertyChanged(nameof(StatusLabelText));

                }
                else if (winner == BlackjackGame.Dealer)
                {
                    // Dealer won.
                    DealerBorderColor = Brushes.DeepSkyBlue;
                    RaisePropertyChanged(nameof(DealerBorderColor));
                    BlackjackGame.Player.Losses++;
                    ChangeDisplayLabel(BlackjackGame.Player.Losses, LABELS.Losses);
                    StatusLabelText = DEALER_WIN_STATUS_TEXT;
                    RaisePropertyChanged(nameof(StatusLabelText));
                }
            }

            IsResetEnabled = false;
            RaisePropertyChanged(nameof(IsResetEnabled));
           IsResetVisible = Visibility.Hidden;
            RaisePropertyChanged(nameof(IsResetVisible));
        IsDisplayLabelVisible = Visibility.Hidden;
            RaisePropertyChanged(nameof(IsDisplayLabelVisible));
        IsRestartEnabled = true;
            RaisePropertyChanged(nameof(IsRestartEnabled));
          IsRestartVisible = Visibility.Visible;
            RaisePropertyChanged(nameof(IsRestartVisible));

            DisplayDealerHand();
        }

        private void RestartGame()
        {
            BlackjackGame.ResetGame();

            DealerBorderColor = Brushes.Green;
            RaisePropertyChanged(nameof(DealerBorderColor));
            PlayerBorderColor = Brushes.Green;
            RaisePropertyChanged(nameof(PlayerBorderColor));

            IsRestartEnabled = false;
            RaisePropertyChanged(nameof(IsRestartEnabled));
           IsRestartVisible = Visibility.Hidden;
            RaisePropertyChanged(nameof(IsRestartVisible));

            IsStartEnabled = true;
            RaisePropertyChanged(nameof(IsStartEnabled));
            IsStartVisible = Visibility.Visible;
            RaisePropertyChanged(nameof(IsStartVisible));

            ChangeTotalLabel(0, PLAYERS.Dealer);
            ChangeTotalLabel(0, PLAYERS.Player);
        }

        private void DisplayDealerHand()
        {
            ChangeTotalLabel(BlackjackGame.Dealer.GetHandTotal(), PLAYERS.Dealer);

            for (int i = 0; i < BlackjackGame.Dealer.CurrentHand.Length; i++)
            {
                UpdateHands(BlackjackGame.Dealer, new HandEventArgs(i, BlackjackGame.Dealer.CurrentHand[i]));
            }
        }

        private void UpdateHands(object sender, HandEventArgs args)
        {
            if (sender is Dealer)
            {
                Card cCard = BlackjackGame.Dealer.GetCard(args.Index, !IsRestartEnabled);
                DealerCardsList[args.Index] = new VMCard(cCard.Values, cCard.Suit);
            }
            else if (sender is Player)
            {
                PlayerCardsList[args.Index] = new VMCard(args.Card.Values, args.Card.Suit);
                ChangeTotalLabel(BlackjackGame.Player.GetHandTotal(), PLAYERS.Player);
            }
        }

        private void ResetGame()
        {
            RestartGame();
            ChangeDisplayLabel(0, LABELS.Wins);
            ChangeDisplayLabel(0, LABELS.Ties);
            ChangeDisplayLabel(0, LABELS.Losses);
            BlackjackGame.Player.Wins = 0;
            BlackjackGame.Player.Ties = 0;
            BlackjackGame.Player.Losses = 0;
            StartGame();
        }


        //Sætter den specifikke label til at være det specifikke nummer 
        private void ChangeDisplayLabel(int num, LABELS label)
        {
            switch (label)
            {
                case LABELS.Wins:
                    WinsDisplay = WINS_DISPLAY_LABEL + num;
                    RaisePropertyChanged(nameof(WinsDisplay));
                    break;
                case LABELS.Ties:
                    TiesDisplay = TIES_DISPLAY_LABEL + num;
                    RaisePropertyChanged(nameof(TiesDisplay));
                    break;
                case LABELS.Losses:
                    LossesDisplay = LOSSES_DISPLAY_LABEL + num;
                    RaisePropertyChanged(nameof(LossesDisplay));
                    break;
            }
            return;
        }

        private void ChangeTotalLabel(int num, PLAYERS player)
        {
            switch (player)
            {
                case PLAYERS.Dealer:
                    if (num == 0)
                    { DealerBoxHeader = DEALER_HIDDEN_HEADER_TEXT; }
                    else
                    { DealerBoxHeader = String.Format(DEALER_HEADER_TEXT, num); }
                    RaisePropertyChanged(nameof(DealerBoxHeader));
                    break;
                case PLAYERS.Player:
                    if (num == 0)
                    { PlayerBoxHeader = PLAYER_HIDDEN_HEADER_TEXT; }
                    else
                    { PlayerBoxHeader = String.Format(PLAYER_HEADER_TEXT, num); }
                    RaisePropertyChanged(nameof(PlayerBoxHeader));
                    break;
            }
        }

        private void RaisePropertyChanged(string propertyName)
        {
            PropertyChangedEventHandler handler = PropertyChanged;

            // Uses null-conditional operator to invoke the event handler if it is not null.
            handler?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
        #endregion
    }

    #region Collection class
    public class AsyncObservableCollection<T> : ObservableCollection<T>
    {

        public AsyncObservableCollection()
        {
        }

        public AsyncObservableCollection(IEnumerable<T> list)
            : base(list)
        {
        }
    }

    #endregion

}
