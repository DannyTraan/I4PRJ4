﻿using System;
using System.Windows.Input;

//Inspiration fra undervisning materiale
//"ConnectingViewsAndViewModels"

namespace BlackjackWPF.ViewModel
{
    public class RelayCommand<T> : ICommand
    {

        #region Constructors

        public RelayCommand(Action<T> execute)
            : this(execute, null)
        {
        }

        public RelayCommand(Action<T> execute, Predicate<T> canExecute)
        {
            if (execute == null)
                throw new ArgumentNullException("execute");

            _execute = execute;
            _canExecute = canExecute;
        }

        #endregion

        #region ICommand Members

        public bool CanExecute(object parameter)
        {
            return _canExecute == null ? true : _canExecute((T)parameter);
        }

        public event EventHandler CanExecuteChanged
        {
            add
            {
                if (_canExecute != null)
                {
                    CommandManager.RequerySuggested += value;
                }
            }
            remove
            {
                if (_canExecute != null)
                {
                    CommandManager.RequerySuggested -= value;
                }
            }
        }

 
        public void Execute(object parameter)
        {
            _execute((T)parameter);
        }

        #endregion

        #region Fields

        readonly Action<T> _execute = null;
        readonly Predicate<T> _canExecute = null;

        #endregion
    }

    public class NoParamRelayCommand<T> : ICommand
    {

        #region Constructors


        public NoParamRelayCommand(Action execute)
            : this(execute, null)
        {
        }

        public NoParamRelayCommand(Action execute, Predicate<T> canExecute)
        {
            if (execute == null)
                throw new ArgumentNullException("execute");

            _execute = execute;
            _canExecute = canExecute;
        }

        #endregion

        #region ICommand Members


        public bool CanExecute(object parameter)
        {
            return _canExecute == null ? true : _canExecute((T)parameter);
        }


        public event EventHandler CanExecuteChanged
        {
            add
            {
                if (_canExecute != null)
                    CommandManager.RequerySuggested += value;
            }
            remove
            {
                if (_canExecute != null)
                    CommandManager.RequerySuggested -= value;
            }
        }


        public void Execute(object parameter)
        {
            _execute();
        }

        public void Execute()
        {
            Execute(new object());
        }
        #endregion

        #region Fields

        readonly Action _execute = null;
        readonly Predicate<T> _canExecute = null;

        #endregion
    }
}
