﻿namespace BlackjackWPF.Model
{
    //Den klasse kan laves om til et interface.
    public abstract class States
    {

        protected Card[] currentHand;
        public Card[] CurrentHand => currentHand;
        public int Wins { get; set; }
        public int Ties { get; set; }
        public int Losses { get; set; }
        public bool IsBusted { get; set; }

    }
}
