﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using BlackjackWPF;



namespace TheDeepCasino.View
{
    /// <summary>
    /// Interaction logic for GamePicker.xaml
    /// </summary>
    public partial class GamePicker : UserControl
    {
        Account account;
        public GamePicker(Account acc)
            {
                InitializeComponent();
                account = acc;
                WelcomeLabel.Content = "Welcome " + acc.GetName() + ". Choose a game lan";
                ChipsLabel.Content = "You have " + acc.GetChips() + " chips lan";
            }


        private void BlackjackButton_Click(object sender, RoutedEventArgs e)
        {
            //MainWindow window = (MainWindow)Window.GetWindow(this);
            //window.SetContent(player, 1);
            //TheDeepCasino.MainWindow mw = (TheDeepCasino.MainWindow)Window.GetWindow(this);
            // mw.SetContent(account, 1);

            BJWindow OP = new BJWindow();
            OP.Show();
        }

            private void RouletteButton_Click(object sender, RoutedEventArgs e)
            {
                MainWindow window = (MainWindow)Window.GetWindow(this);
               // window.SetContent(account, 4);
            }

            private void ReloadButton_Click(object sender, RoutedEventArgs e)
            {
                account.SetChips(500);
                //ChipsLabel.Content = "You have " + account.GetChips() + " chips.";
            }
    }
}
